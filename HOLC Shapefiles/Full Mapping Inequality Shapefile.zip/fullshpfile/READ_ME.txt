Shapefile: This contains the raw polygon shapefile with abbreviated area descriptions

HOLC_Cities.gdb: This contains the raw polygon feature class and associated area descriptions table. These can be joined via the "polygon_id" field. This method is needed to get around character limitations of native shapefiles. 

Updated: May 20th, 2020